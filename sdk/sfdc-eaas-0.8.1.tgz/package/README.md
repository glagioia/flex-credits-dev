# EaaS Client SDK

TypeScript SDK to consume EaaS services from different frontends. Intended to be published in a private Nexus as an npm package and reused in modern web apps without coupling to a specific framework.

## Goal

Centralize frontend access to the Estimations API, with a lightweight SDK that can be reused across apps.

## Architecture

```
src/
  core/
    domain/        # domain types
    services/      # Estimations API
  transport/
    http/          # HTTP clients
  adapters/
    logger/        # decoupled logging
  sdk/             # SDK composition and configuration
  index.ts         # public export
```

### Principles

- **Lightweight and framework-agnostic SDK**: usable from React, Angular, Vue, etc.
- **Simple dependency injection**: providers in configuration, no heavy DI container.
- **Config cache**: estimation configs are cached in memory (singleton).
- **Layered separation**: transport, storage, and services are decoupled.

## Installation

```bash
npm install @sfdc/eaas
```

## Basic usage from a frontend

```ts
import eaasSDK from "@sfdc/eaas/sdk";

const sdk = eaasSDK({
  baseUrl: "https://{environment}.mule-api-gateway.com",
  clientId: "your-client-id",
  clientSecret: "your-client-secret"
});

// Taxonomy (industries, company sizes)
const [industries, companySizes] = await Promise.all([
  sdk.taxonomy.getIndustries(),
  sdk.taxonomy.getCompanySizes()
]);

// Agentforce templates and topics
const templates = await sdk.agentforce.getTemplates();
const topics = await sdk.agentforce.getTopicsByTemplate(templates[0].id);

// Credits for a topic with input values
const totalCredits = await sdk.agentforce.getTotalCreditsByTopic(
  templates[0].id,
  topics[0].id,
  [{ inputKey: "numberOfUsers", value: "10" }]
);
```

Templates and topics are served from the SDK's internal cache. If the cache is
empty, the SDK fetches configuration once and reuses it for later calls.

`baseUrl`, `clientId`, and `clientSecret` are required. The SDK sends them as
`client_id` and `client_secret` headers to match the external mock gateway.

## Internal frontend example (Nuxt)

The internal frontend initializes the SDK on the server only. The SDK is never
created in the browser and secrets are not exposed client-side.

`resources/vuex-test-app/server/utils/sdk.ts`

```ts
import eaasSDK from '@sfdc/eaas/sdk'

export const getSdk = () => {
  const config = useRuntimeConfig()

  if (!config.sdkBaseUrl || !config.sdkClientId || !config.sdkClientSecret) {
    throw new Error('SDK configuration is missing. Check runtimeConfig values.')
  }

  return eaasSDK({
    baseUrl: config.sdkBaseUrl,
    clientId: config.sdkClientId,
    clientSecret: config.sdkClientSecret
  })
}
```

The SDK is exposed to server-side pages via a Nuxt plugin:

`resources/vuex-test-app/app/plugins/sdk.server.ts`

```ts
import type { EaaSClientSDK } from "@sfdc/eaas";
import { getSdk } from "~~/server/utils/sdk";

export default defineNuxtPlugin(() => {
  const sdk = getSdk();
  return {
    provide: {
      sdk: sdk as EaaSClientSDK
    }
  };
});
```

Usage in a server-rendered page (only calls SDK methods, cache stays inside the library):

```ts
const { data } = await useAsyncData("sdk-data", async () => {
  const { $sdk } = useNuxtApp();
  const templates = await $sdk.agentforce.getTemplates();
  const topics = await $sdk.agentforce.getTopicsByTemplate(templates[0].id);
  return { templates, topics };
}, { server: true });
```

Important: `useRuntimeConfig()` runs only on the server inside
`server/utils/sdk.ts`. The frontend never calls configuration endpoints directly.
It only uses `sdk.agentforce.getTemplates()`, `sdk.agentforce.getTopicsByTemplate()`, and
`sdk.agentforce.getTotalCreditsByTopic()`; caching is handled internally by the SDK.


## Technical decisions

- **No DI framework**: Inversify is not used to keep the bundle small and simple.
- **HTTP via `fetch` by default**: it can be replaced with another client.
- **npm publication with subpath**: the recommended import is `@sfdc/eaas/sdk`.

## Available API

- **sdk.estimations** – `createEstimation`, `updateEstimation`, `shareEstimation`, `getConfigs`
- **sdk.agentforce** – `getTemplates`, `getTopicsByTemplate`, `getGatingSkusByTemplate`, `createEstimationConfigItem`, `updateEstimationConfigItemTopicValues`, `updateEstimationConfigItemGatingSkuId`, `addItemToEstimation`, `getTotalCreditsByTopic`, `getTotalPriceByTopic`, and more
- **sdk.data360** – `getDataFoundationInputs`, `getUseCases`, `createEstimationConfigItem`, `updateEstimationConfigItemValues`, `updateEstimationConfigItemUseCaseValues`, `addItemToEstimation`, and more
- **sdk.taxonomy** – `getIndustries`, `getCompanySizes`, `getClouds`, `getSettingByKey`

Full API reference: [docs/](docs/). **What's new in 0.5.0:** Agentforce Employee-facing templates (gating SKU and seats), the **Enhance my Agent** Data 360 use case as an Agentforce topic, and `addItemToEstimation` on `sdk.agentforce` and `sdk.data360`. See [Release notes](docs/release-notes.md).

## Scripts

```bash
npm run build
npm run clean
```
